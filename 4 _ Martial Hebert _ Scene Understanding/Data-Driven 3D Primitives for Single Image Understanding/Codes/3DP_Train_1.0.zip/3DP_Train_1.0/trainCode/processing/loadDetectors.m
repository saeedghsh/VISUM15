function res = loadDetectors(matName)
    globals;
    addpath(genpath(CONFIG.detectorCode));
    load(matName);
    res = detectors; 
end

%% Prepare the suns dataset.

if ~exist('Dtest', 'var') || ~exist('Dtraining', 'var')
  disp('Data not loaded, loading ...');
  load([HCONDATA 'sun09_objectCategories.mat']);
  load([HCONDATA 'sun09_groundTruth.mat']);
  disp('done');
end

%% Get images of a category

sunsTraining = mergeCategories(Dtraining, {{'pillow', 'cushion'}});
sunsTesting = mergeCategories(Dtest, {{'pillow', 'cushion'}});

%%

save([sunsDataDir 'data.mat'], 'sunsTraining', 'sunsTesting');

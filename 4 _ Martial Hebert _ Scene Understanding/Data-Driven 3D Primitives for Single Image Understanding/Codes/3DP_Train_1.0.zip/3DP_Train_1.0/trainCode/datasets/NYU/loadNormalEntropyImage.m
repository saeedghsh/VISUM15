function EI = loadNormalEntropyImage(imPath)
    [path, name, ext] = fileparts(imPath);
    try
        EI = dlmread([path '/' strrep(name,'rgb','ne') '.txt']);
    catch
        EI = [];
    end
end

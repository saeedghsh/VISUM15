% initialize the PASCAL development kit 
tmp = pwd;
addpath(VOCdevkit);
VOCinit;
cd(tmp);

%% Prepare indoor67 data. This is the MIT indoor dataset.

indoor67TrainData = getIndoor67Data('train', CONFIG);
save([CONFIG.indoor67DataDir 'train.mat'], 'indoor67TrainData');
indoor67TestData = getIndoor67Data('test', CONFIG);
save([CONFIG.indoor67DataDir 'test.mat'], 'indoor67TestData');

%%

allLabels = cell(size(indoor67TrainData));
for i = 1 : length(indoor67TrainData)
  allLabels{i} = indoor67TrainData(i).annotation.label;
end

categories = unique(allLabels);

%%

save([CONFIG.indoor67DataDir 'categories.mat'], 'categories');

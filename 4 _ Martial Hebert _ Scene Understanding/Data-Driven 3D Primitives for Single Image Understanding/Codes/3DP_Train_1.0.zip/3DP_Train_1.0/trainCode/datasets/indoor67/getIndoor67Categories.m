function categories = getIndoor67Categories(config)
% All categories for pascal 2007.
%
% Author: saurabh.me (Saurabh Singh).
load([config.indoor67DataDir 'categories.mat'], 'categories');
end

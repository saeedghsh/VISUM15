function data = mergeCategories(data, categories)
% Categories is a cell array of cell array.

for i = 1 : length(data)
  for j = 1 : length(categories)
    cats = categories{j};
    objNames = {data(i).annotation.object.name};
    [present, unused] = ismember(objNames, cats);
    inds = find(present);
    for k = 1 : length(inds)
      data(i).annotation.object(inds(k)).name = cats{1};
    end
  end
end
end

% Test the results
%
% Author: saurabh.me@gmail.com (Saurabh Singh)

% [testPosNew testNegNew] = adjustData(testSetPos, ...
%     testSetNeg, learntgmms{1}, 0.5, primaryCat, secondaryCat, true);
all = [testPosNew testNegNew];
indxs = randperm(length(all));
for i = 1 : length(indxs)
   j = indxs(i);
   fig1 = figure(1); clf;
   [boxes1Cond, boxes2Cond] = my_test('table', ...
      COND_MODEL_WALL_TABLE, all(j:j), 'condwalltable', 10, true);
   fig2 = figure(2); clf;
    [boxes1Base, boxes2Base] = my_test('table', ...
      MODEL_BASE_TABLE, all(j:j), 'basewalltable', 10, true);
   fig3 = figure(3); clf;
   LMplot(all(j), 1, HOMEIMAGES); title('Ground Truth');
    
    print(fig1, '-djpeg', '-r0', sprintf('%d_cond.jpg', j));
    print(fig2, '-djpeg', '-r0', sprintf('%d_base.jpg', j));
    print(fig3, '-djpeg', '-r0', sprintf('%d_gtht.jpg', j));
    %pause
end

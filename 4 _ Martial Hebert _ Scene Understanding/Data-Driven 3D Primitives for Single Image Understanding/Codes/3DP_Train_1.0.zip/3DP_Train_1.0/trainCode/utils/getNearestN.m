function nearN = getNearestN(feat, cent, N)
cr = repmat(cent, size(feat, 1), 1);
dist = feat - cr;
dist = dist.*dist;
sumd = sum(dist, 2);
[~, inds] = sort(sumd', 'ascend');
nearN = inds(1:min(length(inds), N));
end
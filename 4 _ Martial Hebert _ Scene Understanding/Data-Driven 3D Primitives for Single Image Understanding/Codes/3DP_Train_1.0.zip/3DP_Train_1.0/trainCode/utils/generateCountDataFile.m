function generateCountDataFile(names, testData, allData)
fd = fopen('count_data.txt', 'w');
fmtStr = '%s,Test Images: %d; Total Images: %d\n';
for i = 1 : length(names)
  fprintf(fd, fmtStr, names{i}, testData(i), allData(i));
end

function [multPerf, confMat] = computeMultiwayClassificationPerf(scores, labels)
[unused, finL] = max(scores, [], 2);
confMat = zeros(size(scores, 2));
for i = 1 : length(labels)
  confMat(labels(i), finL(i)) = confMat(labels(i), finL(i)) + 1;
end
%
multPerf = trace(confMat) / sum(confMat(:));
end

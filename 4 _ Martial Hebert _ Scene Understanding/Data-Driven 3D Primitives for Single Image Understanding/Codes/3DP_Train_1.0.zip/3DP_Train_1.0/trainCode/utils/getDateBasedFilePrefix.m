function prefix = getDateBasedFilePrefix()
% Utility function to generate date based string to act as a unique
% identifier.
%
% Author: Saurabh Singh (saurabh.me@gmail.com).
dateSuffixFormat = 'yyyy_mm_dd_HH_MM_SS_FFF';
prefix = datestr(now, dateSuffixFormat);
end

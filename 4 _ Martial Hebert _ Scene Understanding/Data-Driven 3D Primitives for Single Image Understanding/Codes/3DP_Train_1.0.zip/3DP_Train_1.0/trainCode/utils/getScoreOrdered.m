function [inds, sc] = getScoreOrdered(results, clust)
sc = zeros(size(results));
for i = 1 : length(results)
  detections = results{i}.firstLevel.detections;
  if ~isempty(detections(clust).decision)
    sc(i) = max(detections(clust).decision);
  end
end
[unused, inds] = sort(sc, 'descend');
end

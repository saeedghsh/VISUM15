function displayDataAsTable(data)
toShow = length(data);
rows = ceil(sqrt(toShow));
cols = ceil(toShow / rows);
fullData = zeros(rows, cols);
fullData(1:length(data)) = data;
fullData = fullData';
t = uitable('parent', gcf, 'Position', [25 25 700 400]);
set(t, 'data', fullData);
set(t, 'ColumnWidth', {50});
end

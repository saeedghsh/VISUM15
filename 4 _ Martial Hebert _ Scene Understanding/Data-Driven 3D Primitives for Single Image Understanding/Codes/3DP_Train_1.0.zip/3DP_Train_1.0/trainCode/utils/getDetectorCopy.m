function obj = getDetectorCopy(detector)
obj = VisualEntityDetectors(detector.firstLevModels, detector.params);
obj.firstLevModels = detector.firstLevModels;
obj.firstLevMmhtWts = detector.firstLevMmhtWts;
obj.params = detector.params;
obj.secondLevModels = detector.secondLevModels;
obj.secondLevMmhtWts = detector.secondLevMmhtWts;
obj.mixModel = detector.mixModel;
obj.successRatio = detector.successRatio;
obj.logisParams = detector.logisParams;
end
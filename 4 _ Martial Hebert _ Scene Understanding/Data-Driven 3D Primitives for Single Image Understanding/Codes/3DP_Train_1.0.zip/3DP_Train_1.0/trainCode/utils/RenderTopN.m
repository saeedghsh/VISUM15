function RenderTopN(topN, file_name)
% Renders the topN as an html table.
fd = fopen(file_name, 'w');
fprintf(fd, '<table>');
for i = 1 : length(topN)
  format_str = '<tr><td>%s</td><td>%s</td><td>%d</td></tr>\n';
  fprintf(fd, format_str, topN(i).category1, topN(i).category2, ...
      topN(i).count);
end
fprintf(fd, '</table>');
fclose(fd);
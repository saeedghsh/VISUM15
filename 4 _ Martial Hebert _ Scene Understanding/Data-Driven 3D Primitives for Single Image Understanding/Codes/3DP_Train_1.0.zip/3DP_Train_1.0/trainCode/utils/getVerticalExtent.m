function ext = getVerticalExtent(obj)
[x,y] = getLMpolygon(obj.polygon);
ext = double(max(y) - min(y));
function s = getEmptyPascalStruct()
s = struct('im', {}, 'x1', {}, 'x2', {}, 'y1', {}, 'y2', {}, ...
    'flip', {}, 'trunc', {}, 'size', {}, 'pyramid', {});
end

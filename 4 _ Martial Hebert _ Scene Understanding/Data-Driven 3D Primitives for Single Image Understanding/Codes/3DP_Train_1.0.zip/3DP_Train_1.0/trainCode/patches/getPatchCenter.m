function [cx cy] = getPatchCenter(data)
cx = (data.x1 + data.x2) / 2;
cy = (data.y1 + data.y2) / 2;
end

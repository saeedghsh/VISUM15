function s = getSubImg(I, D)
% Gets the sub images doing the boundary checking.
%
% Author: saurabh.me@gmail.com (Saurabh Singh).
if D.x1 < 1
  D.x1 = 1;
end
if D.x2 > D.size.ncols
  D.x2 = D.size.ncols;
end
if D.y1 < 1
  D.y1 = 1;
end
if D.y2 > D.size.nrows
  D.y2 = D.size.nrows;
end
s = I(D.y1:D.y2, D.x1:D.x2, :);
end

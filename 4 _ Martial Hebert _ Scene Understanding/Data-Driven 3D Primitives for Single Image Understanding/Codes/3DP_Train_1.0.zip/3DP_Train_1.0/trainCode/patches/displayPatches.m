function displayPatches(patches, params)
% Display the patches in a grid.
%
% Author: saurabh.me@gmail.com (Saurabh Singh)
  
mosaic = getClusterPatchMosaic(patches, params.patchCanonicalSize);
imshow(mosaic);
end

function ext = getPatchVerticalExtent(data)
ext = abs(data.y2 - data.y1) + 1;
end

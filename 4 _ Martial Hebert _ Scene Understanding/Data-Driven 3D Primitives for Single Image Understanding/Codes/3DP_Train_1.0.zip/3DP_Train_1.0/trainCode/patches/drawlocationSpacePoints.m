function drawlocationSpacePoints(negPoints, clr)
hold on;
for i = 1 : size(negPoints, 1)
    x = negPoints(i, 1);
    y = negPoints(i, 2);
    s = negPoints(i, 3);
    a = floor(negPoints(i, 4) * 20);
    plot(x, y, clr, 'LineWidth', 3, 'MarkerSize', 10);
end
hold off;
end

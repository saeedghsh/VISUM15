function visualizeDetections(boxes, data, outDir)
globals;
for i = 1 : length(data)
  imgPath = [HOMEIMAGES data(i).annotation.folder '/' ...
      data(i).annotation.filename];
  I = im2double(imread(imgPath));
  fig1 = figure(1);
  showboxes(I, boxes{i});
  fileName = [outDir sprintf('%d.jpg', i)];
  saveas(fig1, fileName, 'jpg');
end
end

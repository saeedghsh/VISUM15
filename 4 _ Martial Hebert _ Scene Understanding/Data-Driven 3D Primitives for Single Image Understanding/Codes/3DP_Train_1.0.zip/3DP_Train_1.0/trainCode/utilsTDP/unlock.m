function unlock(lockFile)
    rmdir(lockFile);
end

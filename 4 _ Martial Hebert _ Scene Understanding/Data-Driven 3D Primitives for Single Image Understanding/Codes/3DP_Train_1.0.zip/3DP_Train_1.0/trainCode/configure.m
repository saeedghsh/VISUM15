% Set paths and file names

% paths
libHome = 'libs/';
homeDir = '../../';

% Add subdirectories to the path.
addpath(genpath(pwd));

% Add pedro's code to path
addpath([libHome 'voc-release4/']);
% addpath([libHome 'voc-release3.1/']);

% Add libsvm to path.
addpath([libHome 'libsvm-mat-3.0-1/']);

% Add clustering code to path
addpath(genpath([libHome 'yael_v204']));


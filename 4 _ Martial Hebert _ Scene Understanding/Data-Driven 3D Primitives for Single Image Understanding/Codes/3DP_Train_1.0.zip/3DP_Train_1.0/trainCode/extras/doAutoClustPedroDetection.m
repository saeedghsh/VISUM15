function detections = doAutoClustPedroDetection(data, boxes, pedroModel,...
  procDir, distribDir)

inputDir = [procDir distribDir];
detections = cell(1, length(data));
% pedroThresh = pedroModel.thresh;
pedroThresh = -1;
outSuffix = 'distrib';
summer = [];
for i = 1 : length(data)
  imgId = i;
  load([inputDir sprintf('%d_', imgId) outSuffix '.mat'], ...
      'voteSpace');
  disp(i);
%   distribution = distribution;
  summer(i) = sum(voteSpace.space(:));
%   scDist = sum(sum(sum(voteSpace.space, 4), 2), 1);
%   scDist = reshape(scDist, numel(scDist), []);
%   [unused, ordSc] = sort(scDist, 'descend');
%   if summer(i) > eps
%     uniformVote = 1000 / numel(voteSpace.space);
%     voteSpace.space = voteSpace.space + uniformVote;
%   else
%     voteSpace.space = voteSpace.space + 10 / numel(voteSpace.space);
%   end
  
  % Hack
  
%   distribution = distribution + dist2L;
  % hack
  
  bx = boxes{i};
  if isempty(bx)
    continue;
  end
  bx(:, 5) = bx(:, 5) - pedroThresh;
  locCoods = convertBoxToLocationSpaceCoods(bx);
  
%   centx = locCoods(:, 1);
%   centy = locCoods(:, 2);
%   scl = locCoods(:, 3);
%   asp = locCoods(:, 4);
%   
%   wts = interpn(locSpace.ySpace', locSpace.xSpace', ...
%     locSpace.scaleSpace', locSpace.aspectSpace', ...
%     distribution, centy, centx, scl, asp);
  wts = getVoteAtLocations(voteSpace, locCoods);
  
%   wts = wts.^ 2;
  
  % 2D
%   keyboard;
%   distribution = sum(sum(distribution, 4), 3);
%   wts = interpn(locSpace.ySpace', locSpace.xSpace', ...
%     distribution, centy, centx);
  
%   keyboard;
%   rows = data(i).annotation.imagesize.nrows;
%   cols = data(i).annotation.imagesize.ncols;
%   cld = sum(sum(distribution, 4), 3);
%   sumDist = imresize(cld, [rows, cols]);
%   inds = sub2ind([rows, cols], centy, centx);
%   bx(:, 5) = bx(:, 5) .* sumDist(inds) + pedroThresh;
  %%%
%   anno = data(i).annotation;
%   imName = [HOMEIMAGES anno.folder '/' anno.filename];
%   Im = im2double(imread(imName));
%   subplot(2, 2, 1);
%   imagesc(cld); axis equal;
%   subplot(2, 2, 2);
%   imagesc(sumDist); axis equal;
%   subplot(2, 2, 3);
%   imshow(Im); axis equal;
%   fact = sumDist / sum(sumDist(:));
%   fact = fact / max(fact(:));
%   Imfact = Im;
%   Imfact(:, :, 1) = Imfact(:, :, 1) .* fact;
%   Imfact(:, :, 2) = Imfact(:, :, 2) .* fact;
%   Imfact(:, :, 3) = Imfact(:, :, 3) .* fact;
%   subplot(2, 2, 4);
%   imshow(Imfact); axis equal;
%   pause;
  %%%
  if isnan(sum(wts))
    keyboard;
  end
  bx = getFancyNmsBoxes(bx, pedroThresh, wts);
%   bx(:, 5) = bx(:, 5) .* wts + pedroThresh;
  % Do NMS now.
  picks = nms(bx, 0.5);
  bx = bx(picks, :);
  detections{i} = bx;
%   pause;
%   picks = nms(boxes{i}, 0.5);
%   detections{i} = boxes{i}(picks, :);
end
end

function boxs = getFancyNmsBoxes(bx, pedroThresh, wts)
tmpBx = bx;
boxs = [];
while ~isempty(tmpBx)
  tmpBx2 = tmpBx;
  tmpBx2(:, 5) = tmpBx2(:, 5) .* wts + pedroThresh;
  % Do NMS now.
  picks = nms(tmpBx2, 0.5);
  tmpBx2 = tmpBx2(picks, :);
  boxs = [boxs; tmpBx2(1, :)];
  
  tmpBx = tmpBx(picks(2:end), :);
  wts = wts(picks(2:end));
  wts = wts ./ 4;
end
end

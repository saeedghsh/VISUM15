function w = lrTruncGlobalClusterWtFn(y, lrWts, globalWts)
% Function used with the detectors for deterinig the cluster weights.
if isempty(y.decision)
  w = [];
  return;
end
if lrWts{1}(1) < 0 
  w = ones(size(y.decision)) * -1;
else
  w = valLogReg(lrWts{1}, y.decision);
%   w(w<0.05) = -1;
  w(w>=0) = globalWts;
end
end

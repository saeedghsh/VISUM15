function coods = convertPatchToLocationSpaceCoods(patches)
% Helper to get the location a patch
%
% Author: saurabh.me@gmail.com (Saurabh Singh).
coods = zeros(length(patches), 4);
for i = 1 : length(patches)
  [px py] = getPatchCenter(patches(i));
  scale = getPatchVerticalExtent(patches(i));
  asp = getPatchAspectRatio(patches(i));
  coods(i, :) = [px py scale asp];
end    
end

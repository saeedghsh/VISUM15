function w = jointOptModelWtFn(y, p)
% Function used with the detectors for deterinig the cluster weights.
if isempty(y.decision)
  w = [];
  return;
end
if p{1}(1) < 0 
  w = ones(size(y.decision)) * -1;
else
  w = valLogReg(p{1}, y.decision);
end
end

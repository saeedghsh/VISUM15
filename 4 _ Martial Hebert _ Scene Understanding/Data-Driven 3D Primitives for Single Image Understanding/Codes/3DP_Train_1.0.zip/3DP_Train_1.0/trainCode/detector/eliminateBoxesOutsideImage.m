function inImg = eliminateBoxesOutsideImage(points, nrows, ncols)
% Author: saurabh.me@gmail.com (Saurabh Singh).

s1 = points(:, 3) > 1;
s2 = points(:, 1) < ncols;
s3 = points(:, 4) > 1;
s4 = points(:, 2) < nrows;
inImg = s1 & s2 & s3 & s4;
end

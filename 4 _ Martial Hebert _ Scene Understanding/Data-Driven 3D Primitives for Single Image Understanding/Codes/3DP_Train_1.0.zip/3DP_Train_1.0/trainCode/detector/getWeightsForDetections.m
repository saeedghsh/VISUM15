function wts = getWeightsForDetections(wtFn, results)
% Computes the weights for the detections in results using the weight
% function provided.
%
% Author: saurabh.me@gmail.com (Saurabh Singh).

wts = wtFn(results.firstLevel.detections);

end

function [sumDist, sumDist2] = doCondDistributionGenForImage(detectors, ...
  detResult, clusts, space, mmhtWts)

sumDist = doDistributionGenForImage(detectors.firstLevel, ...
  detResult.firstLevel, clusts, space, ones(size(mmhtWts)));
sumDist2 = zeros(size(sumDist));
for i = 1 : length(detectors.secondLevel)
  if ~isempty(detResult.secondLevel{i})
    prefClusts = 1 : length(detectors.secondLevel{i});
    sumDist2 = sumDist2 + doDistributionGenForImage( ...
      detectors.secondLevel{i}, detResult.secondLevel{i}, ...
      prefClusts, space, ones(size(mmhtWts)));
  end
end
end

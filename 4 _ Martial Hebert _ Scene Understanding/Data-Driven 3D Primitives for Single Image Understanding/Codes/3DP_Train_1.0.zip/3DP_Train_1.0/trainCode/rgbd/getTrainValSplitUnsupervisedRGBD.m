function splits = getTrainValSplitUnsupervisedRGBD(trainAllPos, trainAllNeg, trainAllAug)
posSplit = ceil(length(trainAllPos) / 2);
negSplit = ceil(length(trainAllNeg) / 2);
augSplit = ceil(length(trainAllAug) / 2);

if(0)
    splits.trainSetPos = 1 : posSplit;
    splits.validSetPos = posSplit + 1 : length(trainAllPos);
else
    splits.trainSetPos = posSplit + 1 : length(trainAllPos);
    splits.validSetPos = 1 : posSplit;
end
splits.trainSetNeg = 1 : negSplit;
splits.trainSetAug = 1 : augSplit;
splits.validSetNeg = negSplit + 1 : length(trainAllNeg);
splits.validSetAug = augSplit + 1 : length(trainAllAug);
splits.allPos = trainAllPos;
splits.allNeg = trainAllNeg;
splits.allAug = trainAllAug;
end

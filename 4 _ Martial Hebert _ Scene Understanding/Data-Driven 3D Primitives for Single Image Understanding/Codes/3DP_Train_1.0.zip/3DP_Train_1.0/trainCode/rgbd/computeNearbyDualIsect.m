function nIsect = computeNearbyDualIsect(neighbors1, neighbors2)
    NPoints = size(neighbors1,2);
    nIsect = zeros(1,NPoints);
    for i=1:NPoints
        nIsect(i) = numel(intersect(neighbors1(:,i),neighbors2(:,i)));
    end 
end

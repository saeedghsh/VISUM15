global CHUNK_NUM;
CHUNK_NUM = 1;
addpath(genpath('./'));
NYUIter(2);

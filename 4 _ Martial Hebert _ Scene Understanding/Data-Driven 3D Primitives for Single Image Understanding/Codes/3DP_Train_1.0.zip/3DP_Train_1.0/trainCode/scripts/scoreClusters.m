globals;

dataTarget = CONFIG.processedSource;
clusterLocation = 'clusters/';

splitClusterDirectory = [dataTarget '/' clusterLocation];
clusters = dir([splitClusterDirectory '/c_*']);
parfor ci=1:numel(clusters)
    cname = clusters(ci).name;
    fprintf('Handling %s\n', cname);
    computeScores([splitClusterDirectory '/' cname]);
end


This part is very simple: set the variables in globals to the correct
values, and run setup.m

The parts of the code that benefit from parallel processing are written
with parfor, so you can speed up stuff like surface normal computation
by using matlabpool.

Here are the meaning of the paths in globals:

NYUDatasetRemote,NYUSplitRemote: don't touch these.
NYUDatasetLocal: this is where the dataset gets saved. 
    This is a large file (~2.8GB).
NYUSplitLocal: this is where the split file gets saved. 
    This is a small file (2.6KB)
datasetLocation: this is where the processed data goes. 
    This is a large folder (~11GB).

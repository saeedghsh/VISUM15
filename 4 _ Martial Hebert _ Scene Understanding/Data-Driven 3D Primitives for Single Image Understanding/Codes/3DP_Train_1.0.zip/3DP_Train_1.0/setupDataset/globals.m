NYUDatasetRemote = 'http://horatio.cs.nyu.edu/mit/silberman/nyu_depth_v2/nyu_depth_v2_labeled.mat';
NYUSplitRemote = 'http://horatio.cs.nyu.edu/mit/silberman/indoor_seg_sup/splits.mat';


NYUDatasetLocal = 'NYU.mat';
NYUSplitLocal = 'NYUSplit.mat';
datasetLocation = './dataset/';





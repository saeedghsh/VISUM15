function saveNormals(target,nx,ny,nz,depthValid)
    %packaging everything in a parfor is a pain
    save(target,'nx','ny','nz','depthValid');
end

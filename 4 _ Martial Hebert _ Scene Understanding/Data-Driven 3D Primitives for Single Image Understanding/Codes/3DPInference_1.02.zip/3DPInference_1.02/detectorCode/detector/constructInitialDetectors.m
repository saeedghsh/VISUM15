function detectors = constructInitialDetectors(firstTrainDir, ...
  clusterInformation, locationInfo, patchIndexes, params)
% Construct initial set of detectors.

[firstLev, unused, unused] = loadDetectorModels(firstTrainDir, [], ...
  clusterInformation.clustersToProcess, '_det');
detectors = VisualEntityDetectors(firstLev, params);

% [voteMix, allMix] = getPerClusterVoteMix( ...
%   clusterInformation, locationInfo, patchIndexes);
% clustVotes = prepareClusterVotes(voteMix);
% detectors.setMixModel(clustVotes);
end

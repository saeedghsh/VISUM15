function clusterVotes = prepareClusterVotes(voteMix)
% Prepares the vote mixture to be used in the detectors.
%
% Author: saurabh.me@gmail.com (Saurabh Singh).
clusterVotes = cell(size(voteMix));
for i = 1 : length(voteMix)
  clusterVotes{i} = cell2mat(voteMix{i}(:));
end
end

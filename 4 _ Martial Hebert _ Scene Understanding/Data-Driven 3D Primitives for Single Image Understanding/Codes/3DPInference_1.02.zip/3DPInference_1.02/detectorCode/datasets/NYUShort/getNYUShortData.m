function data = getNYUShortData(source)
    files = dir([source '/*.jpg']);
    data = struct('annotation', []);
    data(length(files)).annotation = [];

    for i = 1 : length(files);
        fprintf('parsing files: %d/%d\n', i, length(files));
        I = imread([source files(i).name]);
        [rows, cols, chans] = size(I);
        label = '';
        item = [];
%        item.filename = [source files(i).name];
        item.filename = [files(i).name];
        item.folder = '';
        item.imagesize.nrows = rows;
        item.imagesize.ncols = cols;
        item.label = label;
        object = [];
        object.name = label;
        object.id = 1;
        object.crop = false;
        object.polygon.x = [ ...
        1, ...
        cols, ...
        cols, ...
        1, ...
        ];
        object.polygon.y = [ ...
        1, ...
        1, ...
        rows, ...
        rows, ...
        ];
        object.polygon.t = 1;
        object.polygon.key = 1;

        item.object = object;
        data(i).annotation = item;
    end

        


end 

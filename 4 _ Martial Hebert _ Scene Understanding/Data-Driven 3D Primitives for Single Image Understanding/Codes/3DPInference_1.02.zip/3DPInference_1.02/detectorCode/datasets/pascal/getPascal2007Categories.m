function categories = getPascal2007Categories()
% All categories for pascal 2007.
%
% Author: saurabh.me (Saurabh Singh).
categories = {
  'horse', 'bus', 'tvmonitor', 'cow', 'car', ...
  'bird', 'cat', 'dog', 'aeroplane', 'bicycle', ...
  'motorbike', 'train', 'bottle', 'chair', 'diningtable', ...
  'pottedplant', 'sofa', 'person', 'boat', 'sheep'};
end

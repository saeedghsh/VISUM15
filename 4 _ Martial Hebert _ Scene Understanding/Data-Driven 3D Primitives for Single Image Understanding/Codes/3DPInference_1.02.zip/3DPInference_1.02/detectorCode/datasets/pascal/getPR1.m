function [prec, rec, ap] =  getPR1(clsIndx, testLabs, scores)

out = scores;
[~,si]=sort(-out);
tp=testLabs(si)==clsIndx;
fp=testLabs(si)~=clsIndx;
fp=cumsum(fp);
tp=cumsum(tp);
rec=tp/sum((testLabs==clsIndx)>0);
prec=tp./(fp+tp);
[ap] = VOCap(rec,prec);
end

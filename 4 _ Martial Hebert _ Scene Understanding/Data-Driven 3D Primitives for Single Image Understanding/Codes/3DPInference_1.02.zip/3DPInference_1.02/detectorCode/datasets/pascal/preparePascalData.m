% prepare the pascal data.

pascalTrainData = getPascalData('trainval');
pascalTestData = getPascalData('test');

%%
save([CONFIG.pascalDataDir 'train.mat'], 'pascalTrainData');
save([CONFIG.pascalDataDir 'test.mat'], 'pascalTestData');

%% Prepare the action data

[actionData, actionClasses] = getPascal2010ActionData('trainval', ...
  CONFIG.libHome);
%%

save([CONFIG.pascalDataDir 'actionTrain.mat'], 'actionData', 'actionClasses');

%%

[actionData, actionClasses] = getPascal2010ActionData('test', ...
  CONFIG.libHome);
save([CONFIG.pascalDataDir 'actionTest.mat'], 'actionData', 'actionClasses');


function lev = getInitialLevel(patSize, basePatSize, intervals)
lev1 = floor(intervals * log2(patSize(1) / basePatSize(1)));
lev2 = floor(intervals * log2(patSize(2) / basePatSize(2)));
lev = min(lev1, lev2) + 1;
end

function data = collapseImgHomePath(data, imgHome)
for i = 1 : length(data)
  data(i).annotation.filename = [imgHome data(i).annotation.filename];
end
end

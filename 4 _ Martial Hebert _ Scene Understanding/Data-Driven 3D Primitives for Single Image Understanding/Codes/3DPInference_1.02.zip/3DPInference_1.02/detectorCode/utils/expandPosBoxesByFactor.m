function pos = expandPosBoxesByFactor(pos, factor)
for i = 1 : length(pos)
  h = pos(i).y2 - pos(i).y1;
  w = pos(i).x2 - pos(i).x1;
  mx = (pos(i).x2 + pos(i).x1) / 2;
  my = (pos(i).y2 + pos(i).y1) / 2;
  hi = h * factor / 2;
  wi = w * factor / 2;
  pos(i).x1 = round(mx - wi);
  pos(i).x2 = round(mx + wi);
  pos(i).y1 = round(my - hi);
  pos(i).y2 = round(my + hi);
  pos(i) = clipPatchToBoundary(pos(i));
end
end

function inds = getIndexesFromFiles(rootDir, clustDir)
for i = 1 : length(clustDir)
  fldrName = [rootDir '/' sprintf('%d', clustDir(i)) '/*.jpg'];
  md = dir(fldrName);
  ti = zeros(1, length(md));
  for j = 1 : length(md)
    nm = md(j).name;
    dl = find(nm=='.');
    id = nm(1:dl-1);
%     disp(id);
    ti(j) = str2num(id);
  end
  inds{i} = int32(ti);
end
end
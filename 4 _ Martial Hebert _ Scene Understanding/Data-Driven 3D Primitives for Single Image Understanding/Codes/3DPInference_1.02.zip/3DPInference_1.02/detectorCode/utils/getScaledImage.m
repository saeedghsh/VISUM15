function I1 = getScaledImage(I)
I = imadjust(I, [min(min(I)) max(max(I))], [0 1]);
I = round(I * 256);
I1 = ind2rgb(I, jet(256));
end
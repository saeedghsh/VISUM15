function [gt, numPos] = getGroundTruthDataForCategory(meta, category)
gt(length(meta))=struct('BB',[],'diff',[],'det',[]);
numPos = 0;
for i = 1 : length(meta)
  m = meta(i).annotation;
  objNames = {m.object.name};
  selectedObjs = ismember(objNames, category);
  gt(i).BB = getBoundingBox(m.object(selectedObjs), m);
  gt(i).diff = [m.object.difficult]';
  gt(i).diff = gt(i).diff(selectedObjs);
  gt(i).det = false(sum(selectedObjs), 1);
  numPos = numPos + sum(~gt(i).diff);
%   keyboard;
end
end

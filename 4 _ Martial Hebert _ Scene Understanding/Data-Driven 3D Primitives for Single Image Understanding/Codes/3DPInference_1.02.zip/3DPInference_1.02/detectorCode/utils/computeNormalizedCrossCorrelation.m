function crossCorr = computeNormalizedCrossCorrelation(A, B)
A = bsxfun(@minus,  A, mean(A, 2));
Anorm = sqrt(sum(A .^ 2, 2));
% A = A ./ repmat(Anorm, 1, size(A, 2));
A = bsxfun(@rdivide, A, Anorm);
clear Anorm;
if nargin < 2
  B = A;
else
  B = bsxfun(@minus,  B, mean(B, 2));
  Bnorm = sqrt(sum(B .* B, 2));
  B = B ./ repmat(Bnorm, 1, size(B, 2));
%   B = bsxfun(@rdivide, B, Bnorm);
  clear Bnorm;
end
crossCorr = A * B';
end

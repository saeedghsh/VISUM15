function newIm = convertToImagescImg(im, clrmap)
if nargin < 2
  clrmap = @jet;
end
numColors = 200;
im = double(im);
mp = clrmap(numColors);
numClrs = size(mp, 1);
low = min(im(:));
high = max(im(:));
indImage = im(:);
indImage = round(((indImage - low) ./ (high - low)) * (numClrs - 1)) + 1;
newIm = mp(indImage, :);
newIm  = reshape(newIm, [size(im) 3]);
end

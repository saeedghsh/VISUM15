function createFlagFile(flagFile)
fid = fopen(flagFile, 'w');
fclose(fid);
end

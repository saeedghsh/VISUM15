function freq = computePerCategoryImageStats(allData, imgSet, categories)
% Computes the number of images each category occurs in.
freq = zeros(size(categories));
for i = 1 : length(imgSet)
  objNames = {allData(imgSet(i)).annotation.object.name};
  [mem, unused] = ismember(categories, objNames);
  freq = freq + mem;
end
end

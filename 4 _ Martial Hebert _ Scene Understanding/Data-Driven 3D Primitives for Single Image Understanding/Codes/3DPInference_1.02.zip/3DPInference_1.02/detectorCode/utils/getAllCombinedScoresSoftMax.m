function scores = getAllCombinedScoresSoftMax(classiScores)
scores = ones(size(classiScores{1}));
for i = 1 : length(classiScores)
  scores = scores .* softmax(classiScores{i}')';
end
end

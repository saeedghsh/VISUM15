function showBaselineBoxes(I, detBoxes, data, category, homeImgs)
% Shows the bounding boxes for the specified category in the sun data
% object.
%
% Author: saurabh.me@gmail.com (Saurabh Singh).

[pedPos unused] = convertDataSun09ToPedro(category, data, [], ...
  false, homeImgs);
boxes = zeros(length(pedPos), 4);
for i = 1 : length(pedPos)
  boxes(i, :) = [pedPos(i).x1 pedPos(i).y1 pedPos(i).x2 pedPos(i).y2];
end
% Color values have to be in range 0.0 - 1.0
clr = [0 0 1.0];
myShowBoxesAdv(I, {detBoxes, boxes}, clr);
end

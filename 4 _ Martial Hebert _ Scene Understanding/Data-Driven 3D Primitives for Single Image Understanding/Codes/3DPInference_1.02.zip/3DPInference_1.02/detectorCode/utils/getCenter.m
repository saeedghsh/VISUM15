function [cx cy] = getCenter(obj)
bb = getBoundingBox(obj);
cx = (bb(1) + bb(3)) / 2;
cy = (bb(2) + bb(4)) / 2;
end
function models = getAllPedroModels(modelDir, cats)
% Gets all the pedro models. These are the pretrained models.
%
% Author: saurabh.me@gmail.com (Saurabh Singh).
models = cell(size(cats));
for i = 1 : length(cats)
  fileName = [modelDir cats{i} '_final.mat'];
  load(fileName, 'model');
  models{i} = model;
end
end

function displayPatcheInContext(patch, clr)
if nargin < 2
  clr = 'r';
end
I = imread(patch(1).im);
imshow(I);
hold on;
displayPatchBox(patch, zeros(size(patch)), clr, false)
hold off;
end

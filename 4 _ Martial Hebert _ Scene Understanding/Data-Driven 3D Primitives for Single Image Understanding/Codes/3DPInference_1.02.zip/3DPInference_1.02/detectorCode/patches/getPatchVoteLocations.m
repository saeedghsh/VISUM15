function patVoteLocs = getPatchVoteLocations(locationInfo)
% Gets per patch vote locations in a cell array
%
% Author: saurabh.me@gmail.com (Saurabh Singh)

patVoteLocs = cell(size(locationInfo));
for i = 1 : length(locationInfo)
  xy = reshape(locationInfo(i).xy, 2, [])';
  sc = locationInfo(i).scale';
  asp = locationInfo(i).aspect';
  patVoteLocs{i} = [xy sc asp];
end
end

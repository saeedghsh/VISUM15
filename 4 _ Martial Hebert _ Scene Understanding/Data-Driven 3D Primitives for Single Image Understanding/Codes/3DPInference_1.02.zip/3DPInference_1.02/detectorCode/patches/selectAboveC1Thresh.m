function selPair = selectAboveC1Thresh(pairC1Scores, thresh)
ss = zeros(size(pairC1Scores));
for i = 1 : length(pairC1Scores)
  ss(i) = pairC1Scores{i}(1);
end
selPair = ss > thresh;
end

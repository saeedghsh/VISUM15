function aspect = getPatchAspectRatio(data)
aspect = abs((data.x1 - data.x2) / (data.y1 - data.y2));
aspect = atan(aspect)  / (pi / 2);
end

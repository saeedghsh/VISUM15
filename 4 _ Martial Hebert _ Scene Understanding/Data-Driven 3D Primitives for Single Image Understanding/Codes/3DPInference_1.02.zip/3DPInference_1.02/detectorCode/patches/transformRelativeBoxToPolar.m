function d = transformRelativeBoxToPolar(pairRel)
d = zeros(size(pairRel));
d(:, 1) = sqrt(sum(pairRel(:, 1:2) .* pairRel(:, 1:2), 2));
d(:, 2) = atan2(pairRel(:, 2), pairRel(:, 1));
d(:, 3) = atan(pairRel(:, 3));
end

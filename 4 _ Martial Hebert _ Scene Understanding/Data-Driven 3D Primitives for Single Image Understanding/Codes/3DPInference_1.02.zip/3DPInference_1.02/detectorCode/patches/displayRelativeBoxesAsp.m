function displayRelativeBoxesAsp(bx, clr)
dummyDet.x1 = -0.5;
dummyDet.y1 = -0.5;
dummyDet.x2 = 0.5;
dummyDet.y2 = 0.5;

canoLoc = convertRelativeToCanonicalVoteLocs(dummyDet, bx, 1);
bxCood = convertLocationToBoxCoods(canoLoc{1});
displayPatchBox(bxCood, [], clr);
displayPatchBox(dummyDet, [], 'b');
end

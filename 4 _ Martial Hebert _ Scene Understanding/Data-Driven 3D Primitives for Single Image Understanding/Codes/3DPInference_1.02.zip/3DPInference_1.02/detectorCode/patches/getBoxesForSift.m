function boxes = getBoxesForSift(d, f)
[xall, yall] = myGetSiftDescriptorBox(d, f);
boxes = getBoundingBoxesForPolygons(xall, yall);
end

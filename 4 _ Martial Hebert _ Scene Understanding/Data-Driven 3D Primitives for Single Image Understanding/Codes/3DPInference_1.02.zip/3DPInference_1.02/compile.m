cd detectorCode/voc-release4/
compile

%David Fouhey, Abhinav Gupta, Martial Hebert
%Data-Driven 3D Primitives For Single Image Understanding 
%ICCV 2013
%
%Inference-only code
addpath('3DP/');
addpath('vp/');
addpath('hedauvp/');
addpath('util/');
addpath(genpath('detectorCode/'));
addpath(genpath('leevp/'));

